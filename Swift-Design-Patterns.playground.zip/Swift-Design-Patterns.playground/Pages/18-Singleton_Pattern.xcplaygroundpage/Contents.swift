//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `单例模式（Singleton）`
 * 保证一个类仅有一个实例，并提供一个访问它的全局访问点
 ![](/设计图/单例模式.png)
 ----
 */
import Foundation

// 单例
class SingletonClass {
    var prop = 0
    
    // 静态常量
    static let sharedInstance = SingletonClass()
    
    private init() {}
}

var i = SingletonClass.sharedInstance
i.prop = 100

var j = SingletonClass.sharedInstance
print(j.prop)


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
