//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare) 
/*:
 ## `抽象工厂模式（Abstract Factory）`
 * 提供一个创建一系列相关或相互依赖对象的接口，而无需指定它们具体的类
 ![](/设计图/策略模式.png)
 ----
 */
import Foundation

// 协议
protocol Subject {
    var updates: [() -> ()] { get }
    func notify()
}

class Boss: Subject {
    var updates: [() -> ()] = []

    func notify() {
        for i in 0..<updates.count {
            updates[i]()
        }
    }
}

// 看股票
class StockObserver {
    var name: String
    var sub: Subject
    
    init(_ name: String, _ sub: Subject) {
        self.name = name
        self.sub = sub
    }
    
    func turnOffStockMarket() {
        print("\(name) 关闭股票，继续工作")
    }
}

// 看 NBA
class NBAObserver {
    var name: String
    var sub: Subject
    
    init(_ name: String, _ sub: Subject) {
        self.name = name
        self.sub = sub
    }
    
    func turnOffNBA() {
        print("\(name) 关闭 NBA，继续工作")
    }
}

let boss = Boss()
let colleagueA = StockObserver("A", boss)
let colleagueB = NBAObserver("B", boss)

boss.updates.append(colleagueA.turnOffStockMarket)
boss.updates.append(colleagueB.turnOffNBA)

// 发出通知
boss.notify()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
