/*:
 >#  ***提示***:
  如果显示的是Markdown语法形式，可以在Xcode/Editor/Show Rendered Markup进行显示样式的切换。

 ----
 ## 六个原则:
  * 单一职责原则(SRP),就一个类而言，只做一件事
  * 开放-封闭原则(OCP),是说软件实体（类、模块、函数等等）应该可以拓展，但是不可修改
  * 依赖倒转原则(DIP),A. 高层模块不应该依赖低层模块，两个都应该依赖抽象。B. 抽象不应该依赖细节，细节应该依赖抽象
  * 里氏代换原则(LSP),子类型必须能够替换掉它们的父类型
  * 迪米特法则(LOD),如果两个类不必彼此直接通信，那么这两个类就不应当发生直接的相互作用。如果其中一个类需要调用另一个类的某一个方法的话，可以通过第三者转发这个调用
  * 合成/聚合复用原则(CARP),尽量使用合成/聚合，尽量不要使用类继承
  ----
 ## 目录:
 * [准备工作（Prepare）](00-Table_of_Contents)
 * [简单工厂模式（Simple Factory Pattern）](01-Simple_Factory_Pattern)
 * [工厂方法模式（Factory Method Pattern）](02-Factory_Method_Pattern)
 * [抽象工厂模式（Abstract Factory Pattern）](03-Abstract_Factory_Pattern)
 * [策略模式（Strategy Pattern）](04-Strategy_Pattern)
 * [装饰模式（Decorator Pattern）](05-Decorator_Pattern)
 * [代理模式（Proxy Pattern）](06-Proxy_Pattern)
 * [原型模式（Prototype Pattern）](07-Prototype_Pattern)
 * [模版模式（Template Pattern）](08-Template_Pattern)
 * [外观模式（Facade Pattern）](09-Facade_Pattern)
 * [建造者模式（Builder Pattern）](10-Builder_Pattern)
 * [观察者模式（Observer Pattern）](11-Observer_Pattern)
 * [委托模式（Delegate Pattern）](12-Delegate_Pattern)
 * [状态模式（State Pattern）](13-State_Pattern)
 * [适配器模式（Adapter Pattern）](14-Adapter_Pattern)
 * [备忘录模式（Memento Pattern）](15-Memento_Pattern)
 * [组合模式（Composite Pattern）](16-Composite_Pattern)
 * [迭代器模式（Iterator Pattern）](17-Iterator_Pattern)
 * [单例模式（Singleton Pattern）](18-Singleton_Pattern)
 * [桥接模式（Bridge Pattern）](19-Bridge_Pattern)
 * [命令模式（Command Pattern）](20-Command_Pattern)
 * [职责链模式（Chain of Responsibility Pattern）](21-Chain_of_Responsibility_Pattern)
 * [中介者模式（Mediator Pattern）](22-Mediator_Pattern)
 * [享元模式（Flyweight Pattern）](23-Flyweight_Pattern)
 * [解释器模式（Interpreter Pattern）](24-Interpreter_Pattern)
 * [访问者模式（Visitor Pattern）](25-Visitor_Pattern)
 */

//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
