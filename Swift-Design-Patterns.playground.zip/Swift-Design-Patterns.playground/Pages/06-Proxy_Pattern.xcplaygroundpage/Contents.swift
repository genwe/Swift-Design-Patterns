//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare) 
/*:
 ## `代理模式（Proxy`
 * 为其他对象提供一种代理以控制对这个对象的访问
 ![](/设计图/代理模式.png)
 ----
 */
import Foundation

// 协议
protocol GiveGift {
    func giveDolls()
    func giveFlowers()
    func giveChocolate()
}

// 被追求者
struct SchoolGirl {
    var name = ""
}

// 追求者
struct Pursuit: GiveGift {
    var mm = SchoolGirl()
    
    func giveDolls() {
        print("追求者送 \(mm.name) 洋娃娃")
    }
    
    func giveFlowers() {
        print("追求者送 \(mm.name) 鲜花")
    }
    
    func giveChocolate() {
        print("追求者送 \(mm.name) 巧克力")
    }
}

// 代理
struct Proxy: GiveGift {
    var gg: Pursuit
    
    init(_ mm: SchoolGirl) {
        self.gg = Pursuit(mm: mm)
    }
    
    func giveDolls() {
        gg.giveDolls()
    }
    
    func giveFlowers() {
        gg.giveFlowers()
    }
    
    func giveChocolate() {
        gg.giveChocolate()
    }
}

var girl = SchoolGirl()
girl.name = "Jane"

let p = Proxy(girl)

// 代理替追求者执行
p.giveDolls()
p.giveFlowers()
p.giveChocolate()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
