//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `简单工厂`
 * 将一个具体类的实例化交给一个静态工厂方法来执行，它不属于GOF的23种设计模式，但现实中却经常会用到
 ![](/设计图/简单工厂模式.png)
  ----
 */
import Foundation

// 协议
protocol Operator {
    var num: (Double, Double) { get set }
    
    func getResult() -> Double?
}

// 遵守协议
struct Addition: Operator {
    var num = (0.0, 0.0)
    
    func getResult() -> Double? {
        return num.0 + num.1
    }
}

class Subtraction: Operator {
    var num = (0.0, 0.0)
    
    func getResult() -> Double? {
        return num.0 - num.1
    }
}

struct Multiplication: Operator {
    var num = (0.0, 0.0)
    
    func getResult() -> Double? {
        return num.0 * num.1
    }
}

struct Division: Operator {
    var num = (0.0, 0.0)
    
    func getResult() -> Double? {
        var result: Double?
        if num.1 != 0 {
            result = num.0 / num.1
        }
        return result
    }
}

// 操作符枚举
enum Operators {
    case addition, subtraction, multiplication, division
}

// 工厂
struct OperatorFactory {
    static func calculateForOperator(_ opt: Operators) -> Operator {
        switch opt {
        case .addition:
            return Addition()
        case .subtraction:
            return Subtraction()
        case .multiplication:
            return Multiplication()
        case .division:
            return Division()
        }
    }
}

var testDivision = OperatorFactory.calculateForOperator(.division)
testDivision.num = (1, 0)
print(testDivision.getResult() ?? "Error")

var testAddition = OperatorFactory.calculateForOperator(.addition)
testAddition.num = (1, 1)
print(testAddition.getResult() ?? "Error")


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
