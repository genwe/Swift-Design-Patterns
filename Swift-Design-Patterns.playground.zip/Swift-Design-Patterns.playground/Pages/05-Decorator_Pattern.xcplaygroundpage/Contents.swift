//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `装饰模式(Decorator)`
 * 动态的给一个对象添加一些额外的职责，就增加功能来说，装饰模式比生成子类更加灵活。decorate应该像礼物一样层层封装，每一层都添加新的功能
 ![](/设计图/装饰模式.jpg)
 ----
 */
import Foundation
 
// 协议
protocol Person {
    func show()
}

// 遵守协议
struct Boy: Person {
    var name = ""

    init() {}
    init(_ name: String) {
        self.name = name
    }
    
    func show() {
        print("\(name)")
    }
}

// 饰物遵守协议
class Finery: Person {
    var component: Person
    
    init(_ component: Person) {
        self.component = component
    }
    
    func show() {
        component.show()
    }
}

// 继承
class TShirt: Finery {
    override func show() {
        print("T 恤", separator: "", terminator: " + ")
        super.show()
    }
}

// 继承
class ChineseTunicSuit: Finery {
    override func show() {
        print("中山装", separator: "", terminator: " + ")
        super.show()
    }
}

var b = Boy("Kingcos")

// 按顺序装饰
let tShirtA = TShirt(b)
let chineseTunicSuitA = ChineseTunicSuit(tShirtA)

chineseTunicSuitA.show()

let chineseTunicSuitB = ChineseTunicSuit(b)
let tShirtB = TShirt(chineseTunicSuitB)

tShirtB.show()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
