//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `访问者模式（Visitor）`
 * 表示一个作用于某对象结构中的各元素的操作。它使你可以在不改变各元素的类(男人，女人)的前提下定义作用于这些元素的新操作(喜怒哀乐)。他把数据结构(男人，女人)和作用于数据结构之上的操作(喜怒哀乐)之间的耦合解脱开，使得操作集合可以相对自由地演化
 ![](/设计图/访问者模式.png)
 ----
 */
import Foundation

// 人
class Person: Hashable {
    var name: String
    
    init(_ name: String) {
        self.name = name
    }
    
    var hashValue: Int {
        return name.hashValue
    }
    
    static func ==(l: Person, r: Person) -> Bool {
        return l.hashValue == r.hashValue
    }
    
    func accept(_ visitor: Action) {}
}

// 男
class Man: Person {
    override func accept(_ visitor: Action) {
        visitor.getManConclusion(self)
    }
}

// 女
class Woman: Person {
    override func accept(_ visitor: Action) {
        visitor.getWomanConclusion(self)
    }
}

// 行为 协议
protocol Action {
    func getManConclusion(_ elemA: Man)
    func getWomanConclusion(_ elemB: Woman)
}

// 成功
struct Success: Action {
    func getManConclusion(_ elemA: Man) {
        print("\(type(of: elemA)) \(type(of: self))")
    }
    
    func getWomanConclusion(_ elemB: Woman) {
        print("\(type(of: elemB)) \(type(of: self))")
    }
}

// 失败
struct Failing: Action {
    func getManConclusion(_ elemA: Man) {
        print("\(type(of: elemA)) \(type(of: self))")
    }
    
    func getWomanConclusion(_ elemB: Woman) {
        print("\(type(of: elemB)) \(type(of: self))")
    }
}

// 恋爱
struct Amativeness: Action {
    func getManConclusion(_ elemA: Man) {
        print("\(type(of: elemA)) \(type(of: self))")
    }
    
    func getWomanConclusion(_ elemB: Woman) {
        print("\(type(of: elemB)) \(type(of: self))")
    }
}

// 结婚
struct Marriage: Action {
    func getManConclusion(_ elemA: Man) {
        print("\(type(of: elemA)) \(type(of: self))")
    }
    
    func getWomanConclusion(_ elemB: Woman) {
        print("\(type(of: elemB)) \(type(of: self))")
    }
}

// 对象结构
struct ObjectStructure {
    var elements = Set<Person>()
    
    mutating func attach(_ element: Person) {
        elements.insert(element)
    }
    
    mutating func detach(_ element: Person) {
        elements.remove(element)
    }
    
    func display(_ visitor: Action) {
        for e in elements {
            e.accept(visitor)
        }
    }
}

var os = ObjectStructure()
os.attach(Man("Kingcos"))
os.attach(Woman("Jane"))

let success = Success()
os.display(success)

let failing = Success()
os.display(failing)

let loving = Amativeness()
os.display(loving)

let marriage = Marriage()
os.display(marriage)


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
