//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `中介者模式（Mediator）`
 * 用一个中介对象来封装一系列的对象交互。中介者使各对象不需要显式地相互引用，从而使其耦合松散，而且可以独立地改变它们之间的交互
 ![](/设计图/中介者模式.png)
 ----
 */
import Foundation

// 国家协议
protocol Country {
    var mediator: UnitedNations { get }
}

// 联合国协议
protocol UnitedNations {
    func declare(_ message: String, _ colleague: Country)
}

// A 国
class CountryA: Country {
    var mediator: UnitedNations
    
    init(_ mediator: UnitedNations) {
        self.mediator = mediator
    }
    
    func declare(_ message: String) {
        mediator.declare(message, self)
    }
    
    func getMessage(_ message: String) {
        print("A 国获得消息：\(message)")
    }
}

// B 国
class CountryB: Country {
    var mediator: UnitedNations
    
    init(_ mediator: UnitedNations) {
        self.mediator = mediator
    }
    
    func declare(_ message: String) {
        mediator.declare(message, self)
    }
    
    func getMessage(_ message: String) {
        print("B 国获得消息：\(message)")
    }
}

// 联合国安理会
class UnitedNationsSecurityCouncil: UnitedNations {
    var cA: CountryA?
    var cB: CountryB?
    
    func declare(_ message: String, _ colleague: Country) {
        if type(of: colleague) == type(of: cA!) {
            cB!.getMessage(message)
        } else {
            cA!.getMessage(message)
        }
    }
}

var unsc = UnitedNationsSecurityCouncil()
let cA = CountryA(unsc)
let cB = CountryB(unsc)

unsc.cA = cA
unsc.cB = cB

cA.declare("Message A")
cB.declare("Message B")


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
