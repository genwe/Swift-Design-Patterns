//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `模板方法模式（Template Method）`
 * 定义一个操作中的算法的骨架，而将一些步骤延迟到子类中。模板方法使得子类可以不改变一个算法的结构即可重定义该算法的某些特定步骤
 ![](/设计图/模板方法模式.png)
 ----
 */
import Foundation
 
// 考试协议
protocol Exam {
    func questionA()
    func questionB()
    func questionC()
    
    func answerA() -> String
    func answerB() -> String
    func answerC() -> String
}

// 试卷
class TestPaper: Exam {
    // 模版方法
    func questionA() {
        print("Q&A 1 \(answerA())")
    }
    
    func questionB() {
        print("Q&A 2 \(answerB())")
    }
    
    func questionC() {
        print("Q&A 3 \(answerC())")
    }
    
    func answerA() -> String {
        return ""
    }
    
    func answerB() -> String {
        return ""
    }
    
    func answerC() -> String {
        return ""
    }
}

// A 的试卷
class TestPaperA: TestPaper {
    override func answerA() -> String {
        return "A"
    }
    
    override func answerB() -> String {
        return "B"
    }
    
    override func answerC() -> String {
        return "C"
    }
}

// B 的试卷
class TestPaperB: TestPaper {
    override func answerA() -> String {
        return "C"
    }
    
    override func answerB() -> String {
        return "B"
    }
    
    override func answerC() -> String {
        return "A"
    }
}

let pA = TestPaperA()

pA.questionA()
pA.questionB()
pA.questionC()

let pB = TestPaperB()

pB.questionA()
pB.questionB()
pB.questionC()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
