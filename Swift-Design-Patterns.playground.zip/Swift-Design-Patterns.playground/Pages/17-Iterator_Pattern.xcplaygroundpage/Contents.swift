//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `迭代器模式（Iterator））`
 * 提供一种方法顺序访问一个聚合对象中各个元素，而又不暴露该对象的内部表示
 ![](/设计图/迭代器模式.png)
 ----
 */
import Foundation

// Crowd 序列
struct Crowd: Sequence {
    let end: Int
    
    func makeIterator() -> CrowdIterator {
        return CrowdIterator(self)
    }
}

// Crowd 迭代器
struct CrowdIterator: IteratorProtocol {
    var crowd: Crowd
    var times: Int
    
    init(_ crowd: Crowd) {
        self.crowd = crowd
        times = crowd.end - 1
    }
    
    mutating func next() -> Int? {
        let nextNumber = crowd.end - times
        guard nextNumber <= crowd.end else { return nil }
        
        times -= 1
        return nextNumber
    }
}

// 迭代
for i in Crowd(end: 10) {
    print(i)
}


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
