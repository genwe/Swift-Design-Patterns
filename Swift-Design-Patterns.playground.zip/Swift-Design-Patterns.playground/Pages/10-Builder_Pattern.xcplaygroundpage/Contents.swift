//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `建造者模式（Builder）`
 * 将一个复杂对象的构建与它的表示分离，使得同样的构建过程可以创建不同的表示。它可以将复杂对象的建造过程抽象出来（抽象类别），使这个抽象过程的不同实现方法可以构造出不同表现（属性）的对象
 ![](/设计图/建造者模式.png)
 ----
 */
import Foundation

// 协议
protocol PersonBuilder {
    func buildHead()
    func buildBody()
    func buildLeftArm()
    func buildRightArm()
    func buildLeftLeg()
    func buildRightLeg()
    
    func createPerson()
}

// ThinPerson 遵守协议
struct ThinPerson: PersonBuilder {
    func createPerson() {
        buildHead()
        buildBody()
        buildLeftArm()
        buildRightArm()
        buildLeftLeg()
        buildRightLeg()
    }
    
    func buildHead() {
        print(#function)
    }
    
    func buildBody() {
        print(#function)
    }
    
    func buildLeftArm() {
        print(#function)
    }
    
    func buildRightArm() {
        print(#function)
    }
    
    func buildLeftLeg() {
        print(#function)
    }
    
    func buildRightLeg() {
        print(#function)
    }
}

// FatPerson 遵守协议
struct FatPerson: PersonBuilder {
    func createPerson() {
        buildHead()
        buildBody()
        buildLeftArm()
        buildRightArm()
        buildLeftLeg()
        buildRightLeg()
    }
    
    func buildHead() {
        print(#function)
    }
    
    func buildBody() {
        print(#function)
    }
    
    func buildLeftArm() {
        print(#function)
    }
    
    func buildRightArm() {
        print(#function)
    }
    
    func buildLeftLeg() {
        print(#function)
    }
    
    func buildRightLeg() {
        print(#function)
    }
}

let pA = ThinPerson()
pA.createPerson()

let pB = FatPerson()
pB.createPerson()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
