//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `桥接模式（Bridge）`
 * 把抽象层次结构从其实现中分离出来，使其能够独立改变。抽象层定义了提供客户端使用的上层抽象接口。实现层次结构定义了供抽象层次使用的底层接口。实现类的引用被封装与抽象层的实例中
 ![](/设计图/桥接模式.png)
 ----
 */
import Foundation

// 手机软件协议
protocol HandsetSoft {
    func run()
}

// 手机游戏
struct HandsetGame: HandsetSoft {
    func run() {
        print("Run GAME")
    }
}

// 手机通讯录
struct HandsetAddressList: HandsetSoft {
    func run() {
        print("Run ADDRESS LIST")
    }
}

// 手机品牌协议
protocol HandsetBrand {
    var soft: HandsetSoft { get }
    
    func run()
}

// 品牌 A
struct HandsetBrandA: HandsetBrand {
    var soft: HandsetSoft
    
    func run() {
        soft.run()
    }
}

// 品牌 B
struct HandsetBrandB: HandsetBrand {
    var soft: HandsetSoft
    
    func run() {
        soft.run()
    }
}

var hs = HandsetBrandA(soft: HandsetGame())
hs.run()

hs.soft = HandsetAddressList()
hs.run()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
