//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `观察者模式（Observer）`
 * 定义了一种一对多的依赖关系，让多个观察者对象同时监听某一个主题对象。这个主题对象在状态发生变化时，会通知所有观察者对象，使它们能够自动更新自己
 ![](/设计图/观察者模式.png)
 ----
 */
import Foundation

// 协议
protocol Subject {
    func attach(_ observer: Observer)
    func detach(_ observer: Observer)
    func notify()
}

// 观察者
class Observer: Hashable {
    var name: String
    var sub: Subject
    
    var hashValue: Int {
        return "\(name)".hashValue
    }
    
    static func ==(l: Observer, r: Observer) -> Bool {
        return l.hashValue == r.hashValue
    }
    
    init(_ name: String, _ sub: Subject) {
        self.name = name
        self.sub = sub
    }
    
    func update() {}
}

class Boss: Subject {
    var observers = Set<Observer>()
    
    func attach(_ observer: Observer) {
        observers.insert(observer)
    }
    
    func detach(_ observer: Observer) {
        observers.remove(observer)
    }
    
    func notify() {
        for o in observers {
            o.update()
        }
    }
}

// 看股票
class StockObserver: Observer {
    override func update() {
        print("\(name) 关闭股票，继续工作")
    }
}

// 看 NBA
class NBAObserver: Observer {
    override func update() {
        print("\(name) 关闭 NBA，继续工作")
    }
}

let boss = Boss()
let colleagueA = StockObserver("A", boss)
let colleagueB = NBAObserver("B", boss)

// 添加通知者
boss.attach(colleagueA)
boss.attach(colleagueB)

// 移除通知者
boss.detach(colleagueA)

// 发出通知
boss.notify()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
