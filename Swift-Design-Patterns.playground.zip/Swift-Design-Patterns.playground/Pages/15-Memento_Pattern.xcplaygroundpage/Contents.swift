//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `备忘录模式（Memento）`
 * 在不破坏封装性的前提下，捕获一个对象的内部状态，并在该对象之外保存这个状态。这样以后就可将该对象恢复到原先保存的状态
 ![](/设计图/备忘录模式.png)
 ----
 */
import Foundation

// 游戏角色
struct GameRole {
    var vit: Int
    var atk: Int
    var def: Int
    
    init() {
        vit = 100
        atk = 100
        def = 100
    }
    
    func stateDisplay() {
        print("生命值：\(vit)")
        print("攻击力：\(atk)")
        print("防御力：\(def)")
    }
    
    func saveState() -> RoleStateMemento {
        return RoleStateMemento(vit: vit, atk: atk, def: def)
    }
    
    mutating func recoverState(_ memento: RoleStateMemento) {
        vit = memento.vit
        atk = memento.atk
        def = memento.def
    }
    
    mutating func fight() {
        vit = 0
        atk = 0
        def = 0
    }
}

// 游戏状态备忘
struct RoleStateMemento {
    var vit: Int
    var atk: Int
    var def: Int
}

// 游戏状态管理
struct RoleStateCaretaker {
    var memento: RoleStateMemento
}

var p = GameRole()
p.stateDisplay()

let stateAdmin = RoleStateCaretaker(memento: p.saveState())

p.fight()
p.stateDisplay()

p.recoverState(stateAdmin.memento)
p.stateDisplay()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
