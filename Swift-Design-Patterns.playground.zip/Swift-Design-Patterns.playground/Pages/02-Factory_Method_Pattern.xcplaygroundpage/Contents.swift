//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `工厂方法（Factory Method）`
 * 定义一个用于创建对象的接口，让子类决定实例化哪一个类。工厂方法使一个类的实例化延迟到其子类。相对于简单工厂方法，工厂方法模式把工厂也抽象出来，进行接口、实现分离。这样具体工厂和具体产品可以对应着同时扩充，而不需要修改现有逻辑。当然，使用者也许在不同场景要在一定程度上自己对应的工厂选择
 ![](/设计图/工厂方法模式.png)
 ----
 */ 
import Foundation

// 协议
protocol Operator {
    var num: (Double, Double) { get set }
    
    func getResult() -> Double?
    // 工厂
    static func createOperation() -> Operator
}

// 遵守协议
struct Addition: Operator {
    static func createOperation() -> Operator {
        return Addition()
    }
    
    var num = (0.0, 0.0)
    
    func getResult() -> Double? {
        return num.0 + num.1
    }
}

struct Subtraction: Operator {
    static func createOperation() -> Operator {
        return Subtraction()
    }
    
    var num = (0.0, 0.0)
    
    func getResult() -> Double? {
        return num.0 - num.1
    }
}

struct Multiplication: Operator {
    static func createOperation() -> Operator {
        return Multiplication()
    }
    
    var num = (0.0, 0.0)
    
    func getResult() -> Double? {
        return num.0 * num.1
    }
}

struct Division: Operator {
    static func createOperation() -> Operator {
        return Division()
    }
    
    var num = (0.0, 0.0)
    
    func getResult() -> Double? {
        var result: Double?
        if num.1 != 0 {
            result = num.0 / num.1
        }
        return result
    }
}

var testAddition = Addition.createOperation()
testAddition.num = (2, 3)
print(testAddition.getResult() ?? "Error")

var testDivision = Division.createOperation()
testDivision.num = (2, 0)
print(testDivision.getResult() ?? "Error")


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
