//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare) 
/*:
 ## `适配器模式（Adapter）`
 * 将一个类的接口转换成客户希望的另外一个接口。Adapter模式使得原本由于接口不兼容而不能一起工作的那些类可以在一起工作。适配器模式主要应用于“希望复用一些现存的类，但是接口又与复用环境要求不一致的情况”，在遗留代码复用、类库迁移等方面非常有用
 ![](/设计图/适配器模式.png)
 ----
 */
import Foundation

// 球员协议
protocol Player {
    var name: String { get }
    
    func attack()
    func defense()
}

// 前锋
struct Forwards: Player {
    var name: String
    
    func attack() {
        print("前锋 \(name) 进攻")
    }
    
    func defense() {
        print("前锋 \(name) 防守")
    }
}

// 中锋
struct Center: Player {
    var name: String
    
    func attack() {
        print("中锋 \(name) 进攻")
    }
    
    func defense() {
        print("中锋 \(name) 防守")
    }
}

// 后卫
struct Guards: Player {
    var name: String
    
    func attack() {
        print("后卫 \(name) 进攻")
    }
    
    func defense() {
        print("后卫 \(name) 防守")
    }
}

// 外籍中锋
struct ForeignCenter {
    var name: String
    
    func jinGong() {
        print("外籍中锋 \(name) 进攻")
    }
    
    func fangShou() {
        print("外籍中锋 \(name) 防守")
    }
}

// 翻译
struct Translator: Player {
    var name: String
    var foreignCenter: ForeignCenter
    
    init(name: String) {
        self.name = name
        self.foreignCenter = ForeignCenter(name: name)
    }
    
    func attack() {
        foreignCenter.jinGong()
    }
    
    func defense() {
        foreignCenter.fangShou()
    }
}

let playerA = Forwards(name: "Shane Battier")
playerA.attack()

let playerB = Guards(name: "Tracy McGrady")
playerB.defense()

let playerC = Translator(name: "Ming Yao")
playerC.attack()
playerC.defense()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
