//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `外观模式（Facade）`
 * 为子系统中的一组接口提供一个一致的界面，此模式定义了一个高层接口，这个接口使得这一子系统更加容易使用
 ![](/设计图/外观模式.png)
 ----
 */
import Foundation

// 股票协议
protocol Stock {
    func sell()
    func buy()
}

// 股票 A
struct StockA: Stock {
    func sell() {
        print("StockA 卖出")
    }
    
    func buy() {
        print("StockA 买入")
    }
}

// 股票 B
struct StockB: Stock {
    func sell() {
        print("StockB 卖出")
    }
    
    func buy() {
        print("StockB 买入")
    }
}

// 股票 C
struct StockC: Stock {
    func sell() {
        print("StockC 卖出")
    }
    
    func buy() {
        print("StockC 买入")
    }
}

// 基金
struct Fund {
    var stockA: StockA
    var stockB: StockB
    var stockC: StockC
    
    init() {
        stockA = StockA()
        stockB = StockB()
        stockC = StockC()
    }
    
    func sellAB() {
        stockA.sell()
        stockB.sell()
    }
    
    func buyBC() {
        stockB.buy()
        stockC.buy()
    }
    
    func sellABC() {
        stockA.sell()
        stockB.sell()
        stockC.sell()
    }
    
    func buyABC() {
        stockA.buy()
        stockB.buy()
        stockC.buy()
    }
}

let fundManager = Fund()
fundManager.buyBC()
fundManager.buyABC()
fundManager.sellAB()


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
