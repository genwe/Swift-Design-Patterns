//: [上一页](@previous) - [返回目录](00-Table_of_Contents_Prepare)
/*:
 ## `命令模式（Command）`
 * 将一个请求封装为一个对象，从而使你可用不同的请求对客户进行参数化；对请求排队或记录请求日志，以及支持可撤销的操作
 ![](/设计图/命令模式.png)
 ----
 */
import Foundation

// 烧烤
struct Barbecuer {
    enum BBQ: String {
        case mutton = "烤羊肉串"
        case chickenWing = "烤鸡翅"
    }
    
    var state: BBQ = .mutton
    
    mutating func bakeMutton() {
        state = .mutton
        print("\(state.rawValue)")
    }
    
    mutating func backChickenWing() {
        state = .chickenWing
        print("\(state.rawValue)")
    }
}

// 命令
class Command: Hashable {
    var bbq: Barbecuer
    
    init(_ bbq: Barbecuer) {
        self.bbq = bbq
    }
    
    var hashValue: Int {
        return bbq.state.hashValue
    }
    
    static func ==(l: Command, r: Command) -> Bool {
        return l.hashValue == r.hashValue
    }
    
    func executeCommand() {}
}

// 烤羊肉串命令
class BakeMuttonCommand: Command {
    override init(_ bbq: Barbecuer) {
        super.init(bbq)
        self.bbq.state = .mutton
    }
    
    override func executeCommand() {
        bbq.bakeMutton()
    }
}

// 烤鸡翅命令
class BakeChickenWingCommand: Command {
    override init(_ bbq: Barbecuer) {
        super.init(bbq)
        self.bbq.state = .chickenWing
    }
    
    override func executeCommand() {
        bbq.backChickenWing()
    }
}

// 服务员
struct Waiter {
    var cmdSet = Set<Command>()
    
    mutating func setOrder(_ command: Command) {
        if command.bbq.state == .chickenWing {
            print("没有鸡翅了，请点别的烧烤")
        } else {
            cmdSet.insert(command)
            print("增加订单：\(command.bbq.state.rawValue)")
        }
    }
    
    mutating func removeOrder(_ command: Command) {
        cmdSet.remove(command)
        print("取消订单：\(command.bbq.state.rawValue)")
    }
    
    func notify() {
        for command in cmdSet {
            command.executeCommand()
        }
    }
}

let bbq = Barbecuer()
let muttonA = BakeMuttonCommand(bbq)
let muttonB = BakeMuttonCommand(bbq)
let chickenWingA = BakeChickenWingCommand(bbq)

var waiter = Waiter()

waiter.setOrder(muttonA)
waiter.setOrder(muttonB)
waiter.setOrder(chickenWingA)


//: [下一页](@next) - [返回目录](00-Table_of_Contents_Prepare)
